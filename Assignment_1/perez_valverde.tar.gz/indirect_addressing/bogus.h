void bogus
(
	int * y
)
{

}
