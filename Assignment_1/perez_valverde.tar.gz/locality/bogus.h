void bogus
(
	const double ** matrix
)
{

}
