void bogus
(
	double * a_im,
	double * a_re
)
{

}
